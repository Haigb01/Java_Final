package com.spa.dao;

import com.spa.entity.Details;
import com.spa.tienich.Xjdbc;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DetailsDAO extends SPaDAO<Details, Integer> {

    public void insert(Details model) {
        String sql = "INSERT INTO Details (ten, soluong, madh) VALUES (?, ?, ?)";
        Xjdbc.update(sql,
                model.getTen(),
                model.getSoluong(),
                model.getMadh());
    }

    public void update(Details model) {
    }

    public void delete(Integer ma) {
        String sql = "DELETE FROM Details WHERE madh=?";
        Xjdbc.update(sql, ma);
    }
     public void deletee(String ma) {
        String sql = "DELETE FROM Details WHERE madh=?";
        Xjdbc.update(sql, ma);
    }

    public List<Details> selectAll() {
        String sql = "SELECT * FROM Details ";
        return selectBySql(sql);
    }
    public List<Details> Detail(String madh) {
        String sql = "SELECT * FROM Details where madh =?";
        return selectBySql(sql,madh);
    }
    public Details selectById(Integer ma) {
        String sql = "SELECT * FROM Details WHERE ma=?";
        List<Details> list = selectBySql(sql, ma);
        return list.size() > 0 ? list.get(0) : null;
    }

    protected List<Details> selectBySql(String sql, Object... args) {
        List<Details> list = new ArrayList<>();
        try {
            ResultSet rs = null;
            try {
                rs = Xjdbc.query(sql, args);
                while (rs.next()) {
                    Details entity = new Details();
                    entity.setTen(rs.getString("ten"));
                    entity.setSoluong(rs.getString("soluong"));
                    entity.setMadh(rs.getString("madh"));
                    list.add(entity);
                }
            } finally {
                rs.getStatement().getConnection().close();
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return list;
    }
    
}

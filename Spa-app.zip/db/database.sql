﻿Create database DUAN_1_QLSPA
use DUAN_1_QLSPA


CREATE TABLE NhanVien
(
	MaNV NCHAR(20) PRIMARY KEY NOT NULL,
	HoTen NVARCHAR(50) NOT NULL,
	SDT NVARCHAR(11) NOT NULL,
	MatKhau NVARCHAR(50) NOT NULL,	
	VaiTro BIT NOT NULL
)
 CREATE TABLE KHACHHANG
(
	MaKH NCHAR(20) PRIMARY KEY NOT NULL,
	TenKH NVARCHAR(50) NOT NULL,
	SDT NVARCHAR(11) NOT NULL,
	EMAIL NVARCHAR(100),
	NGAYSINH DATE NOT NULL,
	GIOITINH BIT NOT NULL,
	NGAYDANGKY DATE NOT NULL,
	MANV NCHAR(20) NOT NULL,
	FOREIGN KEY(MANV) REFERENCES NHANVIEN(MANV) ON UPDATE CASCADE 
)

 CREATE TABLE SANPHAM
(
	MASP NCHAR(20) PRIMARY KEY NOT NULL,
	TENSP NVARCHAR(50) NOT NULL,
	GIA INT NOT NULL,
	HINHANH NVARCHAR(255) not null	
)
 CREATE TABLE DICHVU
(
	MADV NCHAR(20) PRIMARY KEY NOT NULL,
	TENDV NVARCHAR(50) NOT NULL,
	CHIPHI INT NOT NULL	
)
 CREATE TABLE dhct
(
	madh NCHAR(10) PRIMARY KEY NOT NULL,
	makh nchar(20) NOT NULL,
	tenkh NVARCHAR(100) NOT NULL,
	tongtien int not null,
	giodat nchar(20) not null,
	ngaydat DATE NOT NULL,
	ttthanhtoan BIT NOT NULL,
	ttdonhang  bit not null,
	FOREIGN KEY(makh) REFERENCES khachhang(makh) ON UPDATE CASCADE 
)
CREATE TABLE Details
(	
	ma INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	ten NVARCHAR(50) NOT NULL,
	soluong NCHAR(5) NOT NULL,
	madh nchar(10) not null,
	FOREIGN KEY(madh) REFERENCES dhct(madh) ON UPDATE CASCADE
)

/*thêm cột hình ảnh cho nhân viên*/
ALTER TABLE NhanVien
  ADD hinhanh NVARCHAR(255) NOT NULL
/*thêm cột trang thai cho khachhang*/
  ALTER TABLE khachhang
 ADD trangthai bit 
   ALTER TABLE dhct
 ADD ngaytt nvarchar(50),manv nchar(20) ,tennv nvarchar(50),FOREIGN KEY(manv) REFERENCES nhanvien(manv)

/*doanh thnu*/
 create proc sp_doanhthu(@thang int,@nam int)
as begin
	select @thang as'thang',count(madh)sodh,sum(tongtien)tien from dhct where month(ngaydat)=@thang and year(ngaydat)=@nam and ttthanhtoan=1 and ttdonhang=0
end
exec sp_doanhthu 6,2020
/*doanh thu ngay*/
select ngaydat as 'ngaydat',count(madh)sodh,sum(tongtien)tien 
from dhct 
where ngaydat='8-6-2022' and ttthanhtoan=1 and ttdonhang=0 group by ngaydat

create proc sp_doanhthungay(@ngay nvarchar(30))
as begin
	select @ngay as 'ngaydat',count(madh)sodh,sum(tongtien)tien 
	from dhct 
	where ngaydat=@ngay and ttthanhtoan=1 and ttdonhang=0 group by ngaydat
end
/*chi tiet doanh thu*/
select * from dhct where month(ngaydat)=8 and ttthanhtoan=1 and ttdonhang=0

select count(madh)sodh,sum(tongtien)tien from dhct where month(ngaydat)=8 and ttthanhtoan=1 and ttdonhang=0

